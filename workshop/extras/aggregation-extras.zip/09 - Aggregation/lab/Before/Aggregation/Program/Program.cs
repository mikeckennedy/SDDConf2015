﻿using System;
using System.Linq;
using AggregationLib;
using MongoDB.Bson;
using MongoDB.Driver.Linq;
using Newtonsoft.Json;

namespace Program
{
	internal class Program
	{
		private static void Main()
		{
			ZipContext ctx = new ZipContext();
			var zips = ctx.Zips.AsQueryable(ExecutionTarget.AggregationFramework);

			// To get you started, we'll do this one for you:
			Console.WriteLine("State with more than 5,000,000:");
			var states = zips
				.GroupBy(z => z.State)
				.Select(g => new {State = g.Key, Pop = g.Sum(z => z.Population)})
				.OrderByDescending(s => s.Pop)
				.Where(s => s.Pop > 5000000);

			foreach (var state in states)
			{
				Console.WriteLine("{0} has\t{1:N0}", state.State, state.Pop);
			}
			Console.WriteLine("Aggregation is:");
			Console.WriteLine(GetAggregationFrameworkModel(states));
			Console.WriteLine();
			Console.WriteLine();


			Console.WriteLine("states with most zip codes");
			Console.WriteLine("TO BE ANSWERED");
			Console.WriteLine("SHOW NATIVE AGGREGATION");
			Console.WriteLine();
			Console.WriteLine();

			Console.WriteLine("Cities with most zip codes");
			Console.WriteLine("TO BE ANSWERED");
			Console.WriteLine("SHOW NATIVE AGGREGATION");
			Console.WriteLine();
			Console.WriteLine();

			Console.WriteLine("Average city size by state");
			Console.WriteLine("TO BE ANSWERED");
			Console.WriteLine("SHOW NATIVE AGGREGATION");
			Console.WriteLine();
			Console.WriteLine();

			Console.WriteLine("States and their largest cities");
			Console.WriteLine("TO BE ANSWERED");
			Console.WriteLine("SHOW NATIVE AGGREGATION");
			Console.WriteLine();
			Console.WriteLine();


			Console.WriteLine("States with most cities");
			Console.WriteLine("TO BE ANSWERED");
			Console.WriteLine("SHOW NATIVE AGGREGATION");
			Console.WriteLine();
			Console.WriteLine();

			Console.Read();
		}


		protected static string GetAggregationFrameworkModel<T>(IQueryable<T> query)
		{
			var model = ((LingToMongoQueryable<T>) query).BuildQueryModel();
			var agg = (AggregationFrameworkModel) model;

			return GetPrettyPrintedJson(agg.ToBsonDocument().ToString());
		}


		public static string GetPrettyPrintedJson(string json)
		{
			dynamic parsedJson = JsonConvert.DeserializeObject(json);
			return JsonConvert.SerializeObject(parsedJson, Formatting.Indented);
		}
	}
}