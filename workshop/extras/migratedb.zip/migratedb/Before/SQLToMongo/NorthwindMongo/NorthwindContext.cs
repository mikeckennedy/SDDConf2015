﻿using System.Linq;
using MongoDB.Driver;
using MongoDB.Kennedy;

namespace NorthwindMongo
{
    public class NorthwindContext : MongoDbDataContext
    {
        public NorthwindContext() : base("northwind")
        {
        }
    }
}
