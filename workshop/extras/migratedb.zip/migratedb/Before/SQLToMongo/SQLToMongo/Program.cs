﻿using System;
using System.Linq;
using MongoDB.Bson;
using NorthwindMongo;
using NorthwindSQL;

namespace SQLToMongo
{
	class Program
	{
		static void Main()
		{
			try
			{
				Run();
			}
			catch (NotImplementedException)
			{
				Console.ForegroundColor = ConsoleColor.Red;
				
				Console.WriteLine("Looks like you are not done yet!");
			}
		}

		private static void Run()
		{
			Console.WriteLine("starting import...");
			var mongo = new NorthwindContext();
			using (var entities = new northwindEntities())
			{
				Console.WriteLine("Importing relational DB from: " + entities.Database.Connection.DataSource);
				// TODO:
				//ImportCategories(entities, mongo);
				//ImportSuppliers(entities, mongo);
				//ImportProducts(entities, mongo);
				throw new NotImplementedException("Do this next.");

				// TODO: Second
				//ImportCustomers(entities, mongo);
			}


			Console.WriteLine("Import done");
			Console.WriteLine();
			const string catName = "Seafood";
			Console.WriteLine(catName + " products:");
			throw new NotImplementedException("Do this next.");

			Console.WriteLine();
			const string supplierCountry = "USA";
			Console.WriteLine(supplierCountry + " products");
			throw new NotImplementedException("Do this next.");
			Console.WriteLine();

			DateTime afterDate = new DateTime(1998, 1, 1);
			throw new NotImplementedException("Do this next.");
			Console.WriteLine();

			Console.Write("Most expensive product: ");
			throw new NotImplementedException("Do this next.");
			Console.WriteLine();

			Console.WriteLine("Who order this product?");
			throw new NotImplementedException("Do this next.");

			Console.WriteLine("done");
			Console.Read();
		}

		static ObjectId GetObjectId(int id)
		{
			string s = id.ToString();
			int len = ObjectId.Empty.ToString().Length;
			return new ObjectId(new String('0', len - s.Length) + s);
		}

		static ObjectId? GetObjectId(int? id)
		{
			if (id == null)
				return null;
			return GetObjectId(id.Value);
		}
	}
}
